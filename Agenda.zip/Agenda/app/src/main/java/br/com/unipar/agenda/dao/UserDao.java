package br.com.unipar.agenda.dao;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

import br.com.unipar.agenda.entities.User;

@Dao
public interface UserDao {

    @Query("SELECT * FROM users u where u.cell_phone = :cellPhone")
    User findByCellPhone(String cellPhone);

    @Insert
    void insertAll(User... users);

    @Delete
    void deleteAll(User... users);
}
